"""
Charts Page v10 - fixed
- All UI updates on main thread via pyqtSignal (fixes QObject thread crash)
- Charts no longer freeze Windows
- WebEngine embedded TradingView
- Resizable active trader
"""

import os, sys, threading

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QComboBox, QSplitter
)
from PyQt6.QtCore import Qt, QUrl, QTimer, QObject, pyqtSignal

# Windows WebEngine sandbox fix
if sys.platform == "win32":
    os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu-sandbox --no-sandbox")
    os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")

HAS_WE = False
try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebEngineCore import QWebEngineSettings
    HAS_WE = True
    print("[Charts] WebEngine available — embedded TradingView enabled")
except Exception as e:
    print(f"[Charts] WebEngine not available: {e}")

from ui.active_trader import ActiveTraderPanel

DIM  = "#8b949e"; BLUE = "#58a6ff"
BG2  = "#161b22"; BG3  = "#21262d"

NASDAQ = {"AAPL","MSFT","GOOGL","AMZN","META","TSLA","NVDA","AMD",
          "INTC","NFLX","PYPL","ADBE","CRM","ORCL","QQQ","TQQQ","SQQQ","ARKK"}
CRYPTO = {"BTC":"COINBASE:BTCUSD","ETH":"COINBASE:ETHUSD","SOL":"COINBASE:SOLUSD"}
INTERVAL_MAP = {
    "1m":"1","3m":"3","5m":"5","15m":"15","30m":"30",
    "1h":"60","2h":"120","4h":"240","1D":"D","1W":"W","1M":"M"
}


def to_tv_sym(sym: str) -> str:
    sym = sym.upper().strip()
    if sym in CRYPTO: return CRYPTO[sym]
    if sym in NASDAQ: return f"NASDAQ:{sym}"
    return f"NYSE:{sym}"


def build_tv_html(tv_sym: str, interval: str) -> str:
    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
* {{margin:0;padding:0;box-sizing:border-box;}}
html,body {{width:100%;height:100%;background:#0d1117;overflow:hidden;}}
#tv {{width:100%;height:100vh;}}
</style>
</head>
<body>
<div id="tv"></div>
<script src="https://s3.tradingview.com/tv.js"></script>
<script>
try {{
  new TradingView.widget({{
    container_id:"tv",autosize:true,
    symbol:"{tv_sym}",interval:"{interval}",
    timezone:"America/New_York",theme:"dark",style:"1",locale:"en",
    toolbar_bg:"#161b22",enable_publishing:false,
    allow_symbol_change:true,withdateranges:true,
    hide_side_toolbar:false,details:true,
    studies:["Volume@tv-basicstudies"],
    overrides:{{"paneProperties.background":"#0d1117","paneProperties.backgroundType":"solid"}}
  }});
}} catch(e) {{
  document.body.innerHTML='<p style="color:#f85149;padding:20px;font-family:monospace">Chart error: '+e+'</p>';
}}
</script>
</body>
</html>"""


class PriceFetcher(QObject):
    """Fetches price data in background thread, emits signal to main thread."""
    price_ready = pyqtSignal(str, float, float, float, float, float, int)

    def __init__(self, api):
        super().__init__()
        self.api = api

    def fetch(self, symbol: str):
        """Call from background thread only."""
        try:
            q    = self.api.get_quote(symbol)
            qd   = q.get("quote", {})
            last = float(qd.get("lastPrice", 0) or 0)
            chg  = float(qd.get("netChange", 0) or 0)
            chgp = float(qd.get("netPercentChangeInDouble", 0) or 0)
            bid  = float(qd.get("bidPrice", 0) or 0)
            ask  = float(qd.get("askPrice", 0) or 0)
            vol  = int(qd.get("totalVolume", 0) or 0)
            if last > 0:
                self.price_ready.emit(symbol, last, chg, chgp, bid, ask, vol)
        except Exception as e:
            print(f"[Charts] price fetch error: {e}")


class ChartsPage(QWidget):
    def __init__(self, api):
        super().__init__()
        self.api = api
        self._symbol = ""
        self._loaded = False
        self._load_pending = False

        # Price fetcher lives on main thread, fetch() called from worker thread
        self._fetcher = PriceFetcher(api)
        self._fetcher.price_ready.connect(self._on_price_ready)

        self._build()

    def _build(self):
        vbox = QVBoxLayout(self)
        vbox.setContentsMargins(0,0,0,0); vbox.setSpacing(0)

        # Header
        hdr = QWidget(); hdr.setFixedHeight(52)
        hdr.setStyleSheet(f"background:{BG2};border-bottom:1px solid #30363d;")
        hh = QHBoxLayout(hdr); hh.setContentsMargins(16,0,16,0); hh.setSpacing(8)
        title = QLabel("📉  Charts  —  TradingView")
        title.setStyleSheet(f"color:{BLUE};font-size:15px;font-weight:bold;")
        hh.addWidget(title); hh.addStretch()
        self._price_lbl = QLabel("")
        self._price_lbl.setStyleSheet("color:#d29922;font-size:13px;font-weight:bold;")
        hh.addWidget(self._price_lbl)
        vbox.addWidget(hdr)

        # Controls
        ctrl = QWidget(); ctrl.setFixedHeight(48)
        ctrl.setStyleSheet(f"background:{BG3};border-bottom:1px solid #30363d;")
        cbox = QHBoxLayout(ctrl); cbox.setContentsMargins(12,0,12,0); cbox.setSpacing(8)
        cbox.addWidget(QLabel("Symbol:"))

        self._sym_input = QLineEdit()
        self._sym_input.setPlaceholderText("e.g. SPY")
        self._sym_input.setFixedWidth(100)
        self._sym_input.textChanged.connect(self._auto_caps)
        self._sym_input.editingFinished.connect(self._on_sym_input_changed)
        cbox.addWidget(self._sym_input)



        cbox.addWidget(QLabel("Interval:"))
        self._interval_cb = QComboBox()
        self._interval_cb.addItems(list(INTERVAL_MAP.keys()))
        self._interval_cb.setCurrentText("1D")
        self._interval_cb.setFixedWidth(70)
        self._interval_cb.currentTextChanged.connect(lambda _: QTimer.singleShot(50, self._load_chart) if self._symbol else None)
        cbox.addWidget(self._interval_cb)
        cbox.addStretch()

        if HAS_WE:
            tv_login_btn = QPushButton("🔑 TradingView Login")
            tv_login_btn.setFixedHeight(30)
            tv_login_btn.setStyleSheet("QPushButton{background:#1e3a5f;color:#58a6ff;border:1px solid #30363d;border-radius:4px;font-size:11px;font-weight:bold;padding:0 10px;} QPushButton:hover{background:#1f6feb;color:#fff;}")
            tv_login_btn.clicked.connect(self._open_tv_login)
            cbox.addWidget(tv_login_btn)

        vbox.addWidget(ctrl)

        # Splitter — chart + active trader
        self._splitter = QSplitter(Qt.Orientation.Horizontal)
        self._splitter.setHandleWidth(6)
        self._splitter.setStyleSheet("QSplitter::handle{background:#30363d;} QSplitter::handle:hover{background:#58a6ff;}")

        if HAS_WE:
            # Persistent profile so TradingView login is remembered
            from PyQt6.QtWebEngineCore import QWebEngineProfile
            import os
            profile_path = os.path.join(os.path.expanduser("~"), ".alphadesk_tv_profile")
            self._profile = QWebEngineProfile("alphadesk_tv")
            self._profile.setPersistentStoragePath(profile_path)
            self._profile.setPersistentCookiesPolicy(
                QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
            from PyQt6.QtWebEngineCore import QWebEnginePage
            self._page = QWebEnginePage(self._profile, self)
            self._view = QWebEngineView()
            self._view.setPage(self._page)
            s = self._profile.settings()
            s.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
            s.setAttribute(QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
            s.setAttribute(QWebEngineSettings.WebAttribute.AllowRunningInsecureContent, True)
            s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
            self._splitter.addWidget(self._view)
        else:
            self._splitter.addWidget(self._build_fallback())

        self._active_trader = ActiveTraderPanel(self.api)
        self._splitter.addWidget(self._active_trader)
        self._splitter.setSizes([1100, 390])
        vbox.addWidget(self._splitter, stretch=1)

        # Price refresh — timer fires on main thread, spawns daemon thread for fetch
        self._price_timer = QTimer()
        self._price_timer.timeout.connect(self._trigger_price_fetch)
        self._price_timer.start(1000)

    def _build_fallback(self):
        w = QWidget()
        v = QVBoxLayout(w); v.setAlignment(Qt.AlignmentFlag.AlignCenter); v.setSpacing(16)
        t = QLabel("📉  TradingView Charts")
        t.setAlignment(Qt.AlignmentFlag.AlignCenter)
        t.setStyleSheet("color:#58a6ff;font-size:18px;font-weight:bold;")
        v.addWidget(t)
        self._tv_sym_lbl = QLabel("Enter a symbol above")
        self._tv_sym_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._tv_sym_lbl.setStyleSheet("color:#d29922;font-size:20px;font-weight:bold;")
        v.addWidget(self._tv_sym_lbl)
        btn = QPushButton("🌐  Open Chart in Browser")
        btn.setFixedHeight(46); btn.setFixedWidth(260)
        btn.setStyleSheet("QPushButton{background:#1f6feb;color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:bold;} QPushButton:hover{background:#388bfd;}")
        btn.clicked.connect(self._open_browser)
        v.addWidget(btn, alignment=Qt.AlignmentFlag.AlignCenter)
        self._price_detail_lbl = QLabel("")
        self._price_detail_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._price_detail_lbl.setStyleSheet("color:#e6edf3;font-size:12px;font-family:Consolas;")
        v.addWidget(self._price_detail_lbl)
        return w

    def _auto_caps(self, text):
        upper = text.upper()
        if upper != text:
            cur = self._sym_input.cursorPosition()
            self._sym_input.blockSignals(True)
            self._sym_input.setText(upper)
            self._sym_input.blockSignals(False)
            self._sym_input.setCursorPosition(cur)

    def set_symbol(self, sym: str):
        self._sym_input.setText(sym.upper())
        QTimer.singleShot(100, self._load_chart)

    def _load_chart(self):
        try:
            sym = self._sym_input.text().strip().upper()
            if not sym or len(sym) > 10 or self._load_pending:
                return
            self._load_pending = True
            self._symbol = sym

            try:
                self._active_trader.set_symbol(sym)
            except Exception as e:
                print(f"[Charts] active_trader.set_symbol error: {e}")

            interval = INTERVAL_MAP.get(self._interval_cb.currentText(), "D")
            tv_sym   = to_tv_sym(sym)

            if HAS_WE:
                html = build_tv_html(tv_sym, interval)
                self._view.setHtml(html, QUrl("https://www.tradingview.com"))
                # Inject watcher after page loads
                self._view.loadFinished.connect(self._on_load_finished)
            else:
                if hasattr(self, '_tv_sym_lbl'):
                    self._tv_sym_lbl.setText(sym)

        except Exception as e:
            print(f"[Charts] _load_chart error: {e}")
        finally:
            self._load_pending = False

    def _inject_symbol_watcher(self):
        """Watch TradingView page title for symbol changes — most reliable method."""
        if not HAS_WE: return
        # Start polling page title every 800ms
        if not hasattr(self, '_sym_poll_timer'):
            self._sym_poll_timer = QTimer()
            self._sym_poll_timer.timeout.connect(self._poll_tv_symbol)
            self._sym_poll_timer.start(800)

    def _poll_tv_symbol(self):
        """
        Read page title to detect symbol changes.
        TradingView sets title to: 'AAPL • Apple Inc. — TradingView'
        or 'NYSE:SPY • SPDR S&P 500 ETF — TradingView'
        """
        if not HAS_WE: return
        def handle(title):
            if not title or not isinstance(title, str): return
            try:
                # Split on bullet point — symbol is before it
                if '•' in title:
                    raw = title.split('•')[0].strip()
                elif '—' in title:
                    raw = title.split('—')[0].strip()
                else:
                    return
                # Handle exchange prefix like NYSE:SPY or NASDAQ:AAPL
                sym = raw.split(':')[-1].strip()
                # Remove any non-alpha characters
                import re
                sym = re.sub(r'[^A-Z]', '', sym.upper())
                if not sym or len(sym) < 1 or len(sym) > 10: return
                if sym == self._symbol: return
                # Valid new symbol — update
                self._symbol = sym
                self._sym_input.setText(sym)
                try:
                    self._active_trader.set_symbol(sym)
                    print(f"[Charts] Symbol synced from TradingView: {sym}")
                except Exception as e:
                    print(f"[Charts] set_symbol error: {e}")
            except Exception as e:
                print(f"[Charts] title parse error: {e}")
        self._view.page().runJavaScript("document.title;", handle)

    def _on_load_finished(self, ok):
        """Called when WebEngine finishes loading a page."""
        if ok:
            QTimer.singleShot(1000, self._inject_symbol_watcher)

    def _on_sym_input_changed(self):
        """Symbol typed manually — update Active Trader only, NOT TradingView."""
        sym = self._sym_input.text().strip().upper()
        if not sym or len(sym) > 10: return
        if sym == self._symbol: return
        self._symbol = sym
        try:
            self._active_trader.set_symbol(sym)
        except Exception as e:
            print(f"[Charts] manual sym update error: {e}")

    def _open_tv_login(self):
        """Load TradingView login page inside the embedded chart."""
        if HAS_WE:
            self._view.setUrl(QUrl("https://www.tradingview.com/accounts/signin/"))

    def _open_browser(self):
        if not self._symbol: return
        import webbrowser
        interval = INTERVAL_MAP.get(self._interval_cb.currentText(), "D")
        webbrowser.open(f"https://www.tradingview.com/chart/?symbol={to_tv_sym(self._symbol)}&interval={interval}")

    def _trigger_price_fetch(self):
        """Called on main thread by QTimer. Spawns worker thread for network call."""
        if not self._symbol: return
        sym = self._symbol
        fetcher = self._fetcher
        threading.Thread(target=fetcher.fetch, args=(sym,), daemon=True).start()

    def _on_price_ready(self, symbol, last, chg, chgp, bid, ask, vol):
        """Called on main thread via signal — safe to update UI here."""
        if symbol != self._symbol: return
        sign  = "+" if chg >= 0 else ""
        color = "#3fb950" if chg >= 0 else "#f85149"
        self._price_lbl.setText(
            f"{symbol}  ${last:.2f}  "
            f"<span style='color:{color}'>{sign}{chg:.2f} ({sign}{chgp:.2f}%)</span>")
        if not HAS_WE:
            if hasattr(self, '_price_detail_lbl'):
                self._price_detail_lbl.setText(
                    f"Last: ${last:.2f}   Bid: ${bid:.2f}   Ask: ${ask:.2f}\n"
                    f"Change: {sign}{chg:.2f} ({sign}{chgp:.2f}%)   Vol: {vol:,}")
            if hasattr(self, '_tv_sym_lbl'):
                self._tv_sym_lbl.setText(f"{symbol}  ${last:.2f}")

    def on_show(self):
        if not self._loaded:
            self._loaded = True
