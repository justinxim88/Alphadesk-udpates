"""
Floating Trade Window v13
- Auto-updates bid/ask every second
- Option contract selector (expiration + strike picker)
- Equity and options support
- Stays on top while watching charts
- Fixed rejection notifications
"""

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QComboBox, QDoubleSpinBox, QSpinBox,
    QWidget, QFrame, QButtonGroup, QRadioButton, QTabWidget
)
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QColor

from ui.toast import notify
from api.trade_store import trade_store

GREEN  = "#3fb950"; RED    = "#f85149"; BLUE   = "#58a6ff"
YELLOW = "#d29922"; DIM    = "#8b949e"; BG     = "#0d1117"
BG2    = "#161b22"; BG3    = "#21262d"; PURPLE = "#c792ea"

INPUT_STYLE = f"""
    QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox {{
        background: {BG};
        color: #e6edf3;
        border: 1px solid #30363d;
        border-radius: 4px;
        padding: 6px 10px;
        font-size: 13px;
        font-family: Consolas;
    }}
    QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus {{
        border: 2px solid {BLUE};
    }}
    QComboBox QAbstractItemView {{
        background: {BG2};
        color: #e6edf3;
        selection-background-color: #1f6feb;
    }}
    QDoubleSpinBox::up-button, QDoubleSpinBox::down-button,
    QSpinBox::up-button, QSpinBox::down-button {{
        background: #30363d; border: none; width: 20px;
    }}
"""
LBL = "color: #8b949e; font-size: 11px; font-weight: bold;"


class ChainFetcher(QThread):
    done = pyqtSignal(dict)
    def __init__(self, api, sym): super().__init__(); self.api=api; self.sym=sym
    def run(self):
        try: self.done.emit(self.api.get_options_chain(self.sym, strike_count=20))
        except: self.done.emit({})


class PriceBridge(QObject):
    """Bridge to safely pass price data from background thread to UI."""
    price_ready = pyqtSignal(float, float, float)

class TradeWindow(QDialog):
    def __init__(self, parent, api, symbol=""):
        super().__init__(parent, Qt.WindowType.Window |
                         Qt.WindowType.WindowStaysOnTopHint)
        self.api = api
        self.setWindowTitle("⚡ Trade")
        self.setMinimumWidth(360)
        self.setMaximumWidth(420)
        self.setStyleSheet(f"QDialog{{background:{BG2};color:#e6edf3;}} QLabel{{color:#e6edf3;}}")
        self._symbol       = ""
        self._last_price   = 0.0
        self._bid          = 0.0
        self._ask          = 0.0
        self._chain_data   = {}
        self._chain_threads = []
        self._build()

        # Auto-refresh price every second
        self._price_timer = QTimer()
        self._price_timer.timeout.connect(self._auto_refresh_price)
        self._price_timer.start(1000)

        if symbol:
            self._sym_input.setText(symbol.upper())
            self._symbol = symbol.upper()
            QTimer.singleShot(300, self._fetch_price)

    def _lbl(self, text):
        l = QLabel(text); l.setStyleSheet(LBL); return l

    def _radio(self, text, checked):
        r = QRadioButton(text); r.setChecked(checked)
        r.setStyleSheet(f"QRadioButton{{color:#e6edf3;font-size:12px;font-weight:bold;}} QRadioButton::indicator{{width:14px;height:14px;border-radius:7px;border:2px solid #30363d;background:{BG};}} QRadioButton::indicator:checked{{background:{BLUE};border:2px solid {BLUE};}}")
        return r

    def _build(self):
        vbox = QVBoxLayout(self)
        vbox.setContentsMargins(16,16,16,16); vbox.setSpacing(10)

        # Title
        title = QLabel("⚡  Quick Trade")
        title.setStyleSheet(f"color:{BLUE};font-size:15px;font-weight:bold;")
        vbox.addWidget(title)

        div = QFrame(); div.setFrameShape(QFrame.Shape.HLine)
        div.setStyleSheet("color:#30363d;"); vbox.addWidget(div)

        # Tabs: Equity | Options
        self._tabs = QTabWidget()
        self._tabs.setStyleSheet(f"""
            QTabWidget::pane{{border:1px solid #30363d;background:{BG2};border-radius:4px;}}
            QTabBar::tab{{background:{BG3};color:{DIM};padding:7px 16px;border:none;font-size:12px;}}
            QTabBar::tab:selected{{background:{BG2};color:#e6edf3;border-bottom:2px solid {BLUE};}}
        """)
        self._tabs.addTab(self._build_equity_tab(), "📈  Equity")
        self._tabs.addTab(self._build_options_tab(), "🔗  Options")
        vbox.addWidget(self._tabs)

    def _build_equity_tab(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.setContentsMargins(12,12,12,12); v.setSpacing(8)

        # Symbol
        v.addWidget(self._lbl("Symbol"))
        sym_row = QHBoxLayout(); sym_row.setSpacing(8)
        self._sym_input = QLineEdit(); self._sym_input.setPlaceholderText("SPY")
        self._sym_input.setFixedHeight(36); self._sym_input.setStyleSheet(INPUT_STYLE)
        self._sym_input.textChanged.connect(self._auto_caps_eq)
        self._sym_input.returnPressed.connect(self._fetch_price)
        self._sym_input.editingFinished.connect(self._fetch_price)
        sym_row.addWidget(self._sym_input)
        get_btn = QPushButton("Go"); get_btn.setFixedSize(50,36)
        get_btn.setStyleSheet(f"QPushButton{{background:#30363d;color:#e6edf3;border:1px solid #30363d;border-radius:4px;font-size:12px;font-weight:bold;}} QPushButton:hover{{background:{BLUE};color:#fff;}}")
        get_btn.clicked.connect(self._fetch_price)
        sym_row.addWidget(get_btn)
        v.addLayout(sym_row)

        # Live price display
        self._eq_price_lbl = QLabel("Last: —   Bid: —   Ask: —")
        self._eq_price_lbl.setStyleSheet(f"color:{YELLOW};font-size:12px;font-weight:bold;padding:4px 0;")
        v.addWidget(self._eq_price_lbl)

        # Instruction
        v.addWidget(self._lbl("Instruction"))
        self._eq_instr = QComboBox(); self._eq_instr.setFixedHeight(36)
        self._eq_instr.addItems(["BUY","SELL","SELL_SHORT","BUY_TO_COVER"])
        self._eq_instr.setStyleSheet(INPUT_STYLE)
        self._eq_instr.currentTextChanged.connect(self._update_eq_btn)
        v.addWidget(self._eq_instr)

        # Order type
        v.addWidget(self._lbl("Order Type"))
        self._eq_otype = QComboBox(); self._eq_otype.setFixedHeight(36)
        self._eq_otype.addItems(["LIMIT","MARKET","STOP","STOP_LIMIT"])
        self._eq_otype.setStyleSheet(INPUT_STYLE)
        self._eq_otype.currentTextChanged.connect(self._toggle_eq_prices)
        v.addWidget(self._eq_otype)

        # Qty
        v.addWidget(self._lbl("Quantity"))
        self._eq_qty = QSpinBox(); self._eq_qty.setRange(1,100000)
        self._eq_qty.setValue(1); self._eq_qty.setFixedHeight(36)
        self._eq_qty.setStyleSheet(INPUT_STYLE)
        v.addWidget(self._eq_qty)

        qty_row = QHBoxLayout(); qty_row.setSpacing(4)
        for qv in [1,5,10,25,50,100]:
            b = QPushButton(str(qv)); b.setFixedHeight(28)
            b.setStyleSheet(f"QPushButton{{background:{BG3};color:#ffffff;border:1px solid #58a6ff;border-radius:3px;font-size:11px;font-weight:bold;}} QPushButton:hover{{background:#1f6feb;color:#fff;}}")
            b.clicked.connect(lambda _,vv=qv: self._eq_qty.setValue(vv))
            qty_row.addWidget(b)
        v.addLayout(qty_row)

        # Limit price
        self._eq_lim_lbl = QLabel("Limit Price"); self._eq_lim_lbl.setStyleSheet(LBL)
        v.addWidget(self._eq_lim_lbl)
        self._eq_lim = QDoubleSpinBox(); self._eq_lim.setRange(0,999999)
        self._eq_lim.setDecimals(2); self._eq_lim.setFixedHeight(36)
        self._eq_lim.setStyleSheet(INPUT_STYLE)
        v.addWidget(self._eq_lim)

        # Stop price
        self._eq_stop_lbl = QLabel("Stop Price"); self._eq_stop_lbl.setStyleSheet(LBL)
        v.addWidget(self._eq_stop_lbl)
        self._eq_stop = QDoubleSpinBox(); self._eq_stop.setRange(0,999999)
        self._eq_stop.setDecimals(2); self._eq_stop.setFixedHeight(36)
        self._eq_stop.setStyleSheet(INPUT_STYLE)
        v.addWidget(self._eq_stop)

        # Session / Duration
        sd = QHBoxLayout(); sd.setSpacing(8)
        sc = QVBoxLayout(); sc.addWidget(self._lbl("Session"))
        self._eq_sess = QComboBox(); self._eq_sess.setFixedHeight(34)
        self._eq_sess.addItems(["NORMAL","PRE_MARKET","AFTER_HOURS","SEAMLESS"])
        self._eq_sess.setStyleSheet(INPUT_STYLE); sc.addWidget(self._eq_sess)
        dc = QVBoxLayout(); dc.addWidget(self._lbl("Duration"))
        self._eq_dur = QComboBox(); self._eq_dur.setFixedHeight(34)
        self._eq_dur.addItems(["DAY","GTC","GTC_EXT","GTD","FOK"])
        self._eq_dur.setStyleSheet(INPUT_STYLE); dc.addWidget(self._eq_dur)
        sd.addLayout(sc); sd.addLayout(dc); v.addLayout(sd)

        # Est value
        self._eq_est = QLabel("")
        self._eq_est.setStyleSheet(f"color:{DIM};font-size:11px;")
        v.addWidget(self._eq_est)
        self._eq_qty.valueChanged.connect(self._update_eq_est)
        self._eq_lim.valueChanged.connect(self._update_eq_est)

        # Send button
        self._eq_btn = QPushButton("SEND ORDER"); self._eq_btn.setFixedHeight(46)
        self._eq_btn.setStyleSheet(f"QPushButton{{background:#238636;color:#fff;border:none;border-radius:6px;font-size:14px;font-weight:bold;}} QPushButton:hover{{background:#2ea043;}}")
        self._eq_btn.clicked.connect(self._send_equity)
        v.addWidget(self._eq_btn)

        self._toggle_eq_prices("MARKET")
        return w

    def _build_options_tab(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.setContentsMargins(12,12,12,12); v.setSpacing(8)

        # Symbol
        v.addWidget(self._lbl("Underlying Symbol"))
        opt_sym_row = QHBoxLayout(); opt_sym_row.setSpacing(8)
        self._opt_sym = QLineEdit(); self._opt_sym.setPlaceholderText("SPY")
        self._opt_sym.setFixedHeight(36); self._opt_sym.setStyleSheet(INPUT_STYLE)
        self._opt_sym.textChanged.connect(self._auto_caps_opt)
        self._opt_sym.returnPressed.connect(self._load_chain)
        self._opt_sym.editingFinished.connect(self._load_chain)
        opt_sym_row.addWidget(self._opt_sym)
        chain_btn = QPushButton("Load"); chain_btn.setFixedSize(60,36)
        chain_btn.setStyleSheet(f"QPushButton{{background:#1f6feb;color:#fff;border:none;border-radius:4px;font-size:12px;font-weight:bold;}} QPushButton:hover{{background:#388bfd;}}")
        chain_btn.clicked.connect(self._load_chain)
        opt_sym_row.addWidget(chain_btn)
        v.addLayout(opt_sym_row)

        # Live price
        self._opt_price_lbl = QLabel("Last: —   Bid: —   Ask: —")
        self._opt_price_lbl.setStyleSheet(f"color:{YELLOW};font-size:12px;font-weight:bold;padding:4px 0;")
        v.addWidget(self._opt_price_lbl)

        # Expiration
        v.addWidget(self._lbl("Expiration"))
        self._opt_exp = QComboBox(); self._opt_exp.setFixedHeight(36)
        self._opt_exp.setStyleSheet(INPUT_STYLE)
        self._opt_exp.currentTextChanged.connect(self._on_exp_changed)
        v.addWidget(self._opt_exp)

        # Call/Put + Strike row
        cp_row = QHBoxLayout(); cp_row.setSpacing(12)
        cp_col = QVBoxLayout(); cp_col.addWidget(self._lbl("Type"))
        self._opt_cp = QComboBox(); self._opt_cp.addItems(["CALL","PUT"])
        self._opt_cp.setFixedHeight(36); self._opt_cp.setStyleSheet(INPUT_STYLE)
        self._opt_cp.currentTextChanged.connect(self._on_cp_changed)
        cp_col.addWidget(self._opt_cp)
        sk_col = QVBoxLayout(); sk_col.addWidget(self._lbl("Strike"))
        self._opt_strike = QComboBox(); self._opt_strike.setFixedHeight(36)
        self._opt_strike.setStyleSheet(INPUT_STYLE)
        self._opt_strike.currentTextChanged.connect(self._on_strike_changed)
        sk_col.addWidget(self._opt_strike)
        cp_row.addLayout(cp_col); cp_row.addLayout(sk_col)
        v.addLayout(cp_row)

        # Selected contract display
        self._opt_contract_lbl = QLabel("—")
        self._opt_contract_lbl.setStyleSheet(f"color:#c792ea;font-size:11px;font-family:Consolas;")
        v.addWidget(self._opt_contract_lbl)

        # Contract bid/ask
        self._opt_contract_price = QLabel("")
        self._opt_contract_price.setStyleSheet(f"color:{YELLOW};font-size:12px;font-weight:bold;")
        v.addWidget(self._opt_contract_price)

        # Instruction
        v.addWidget(self._lbl("Instruction"))
        self._opt_instr = QComboBox(); self._opt_instr.setFixedHeight(36)
        self._opt_instr.addItems(["BUY_TO_OPEN","SELL_TO_OPEN","BUY_TO_CLOSE","SELL_TO_CLOSE"])
        self._opt_instr.setStyleSheet(INPUT_STYLE)
        self._opt_instr.currentTextChanged.connect(self._update_opt_btn)
        v.addWidget(self._opt_instr)

        # Qty
        v.addWidget(self._lbl("Contracts"))
        self._opt_qty = QSpinBox(); self._opt_qty.setRange(1,1000)
        self._opt_qty.setValue(1); self._opt_qty.setFixedHeight(36)
        self._opt_qty.setStyleSheet(INPUT_STYLE)
        v.addWidget(self._opt_qty)

        # Limit price
        v.addWidget(self._lbl("Limit Price"))
        self._opt_lim = QDoubleSpinBox(); self._opt_lim.setRange(0,99999)
        self._opt_lim.setDecimals(2); self._opt_lim.setFixedHeight(36)
        self._opt_lim.setStyleSheet(INPUT_STYLE)
        v.addWidget(self._opt_lim)

        # Session/Duration
        sd = QHBoxLayout(); sd.setSpacing(8)
        sc2 = QVBoxLayout(); sc2.addWidget(self._lbl("Session"))
        self._opt_sess = QComboBox(); self._opt_sess.setFixedHeight(34)
        self._opt_sess.addItems(["NORMAL","PRE_MARKET","AFTER_HOURS","SEAMLESS"])
        self._opt_sess.setStyleSheet(INPUT_STYLE); sc2.addWidget(self._opt_sess)
        dc2 = QVBoxLayout(); dc2.addWidget(self._lbl("Duration"))
        self._opt_dur = QComboBox(); self._opt_dur.setFixedHeight(34)
        self._opt_dur.addItems(["DAY","GTC","GTC_EXT"])
        self._opt_dur.setStyleSheet(INPUT_STYLE); dc2.addWidget(self._opt_dur)
        sd.addLayout(sc2); sd.addLayout(dc2); v.addLayout(sd)

        # Send
        self._opt_btn = QPushButton("SEND ORDER"); self._opt_btn.setFixedHeight(46)
        self._opt_btn.setStyleSheet(f"QPushButton{{background:#238636;color:#fff;border:none;border-radius:6px;font-size:14px;font-weight:bold;}} QPushButton:hover{{background:#2ea043;}}")
        self._opt_btn.clicked.connect(self._send_option)
        v.addWidget(self._opt_btn)
        return w

    # ── AUTO CAPS ────────────────────────────────────────────

    def _auto_caps_eq(self, t):
        u = t.upper()
        if u!=t:
            cur=self._sym_input.cursorPosition()
            self._sym_input.blockSignals(True); self._sym_input.setText(u); self._sym_input.blockSignals(False)
            self._sym_input.setCursorPosition(cur)

    def _auto_caps_opt(self, t):
        u = t.upper()
        if u!=t:
            cur=self._opt_sym.cursorPosition()
            self._opt_sym.blockSignals(True); self._opt_sym.setText(u); self._opt_sym.blockSignals(False)
            self._opt_sym.setCursorPosition(cur)

    # ── PRICE FETCH ──────────────────────────────────────────

    def _fetch_price(self):
        sym = self._sym_input.text().strip().upper()
        if not sym: return
        self._symbol = sym
        import threading
        threading.Thread(target=self._do_fetch, args=(sym,), daemon=True).start()

    def _do_fetch(self, sym):
        """Run in background thread — emit signal to update UI safely."""
        try:
            q  = self.api.get_quote(sym)
            qd = q.get("quote",{})
            last = float(qd.get("lastPrice",0) or 0)
            bid  = float(qd.get("bidPrice",0) or 0)
            ask  = float(qd.get("askPrice",0) or 0)
            self._bridge.price_ready.emit(last, bid, ask)
        except Exception as e:
            print(f"[TradeWindow] fetch error: {e}")

    def _on_price_ready(self, last, bid, ask):
        """Called on main thread via signal."""
        self._last_price = last
        self._bid = bid
        self._ask = ask
        self._eq_price_lbl.setText(
            f"Last: ${last:.2f}   "
            f"<span style='color:#3fb950'>Bid: ${bid:.2f}</span>   "
            f"<span style='color:#f85149'>Ask: ${ask:.2f}</span>")
        otype = self._eq_otype.currentText()
        instr = self._eq_instr.currentText()
        if otype == "LIMIT":
            price = ask if "BUY" in instr else bid
            if price > 0:
                self._eq_lim.setValue(price)
        self._update_eq_est()

    def _auto_refresh_price(self):
        """Called every second — refresh price for active tab."""
        if self._tabs.currentIndex() == 0:
            sym = self._sym_input.text().strip().upper()
            if sym: 
                import threading
                threading.Thread(target=self._do_fetch, args=(sym,), daemon=True).start()
        else:
            sym = self._opt_sym.text().strip().upper()
            if sym and self._chain_data:
                import threading
                threading.Thread(target=self._do_fetch_opt_price, args=(sym,), daemon=True).start()

    def _do_fetch_opt_price(self, sym):
        try:
            q = self.api.get_quote(sym)
            qd = q.get("quote",{})
            last = float(qd.get("lastPrice",0) or 0)
            bid  = float(qd.get("bidPrice",0) or 0)
            ask  = float(qd.get("askPrice",0) or 0)
            self._opt_price_lbl.setText(
                f"Last: ${last:.2f}   "
                f"<span style='color:#3fb950'>Bid: ${bid:.2f}</span>   "
                f"<span style='color:#f85149'>Ask: ${ask:.2f}</span>")
        except: pass

    # ── OPTIONS CHAIN ────────────────────────────────────────

    def _load_chain(self):
        sym = self._opt_sym.text().strip().upper()
        if not sym: return
        t = ChainFetcher(self.api, sym)
        t.done.connect(self._on_chain); t.done.connect(lambda _: self._chain_threads.remove(t) if t in self._chain_threads else None)
        self._chain_threads.append(t); t.start()

    def _on_chain(self, data: dict):
        if not data: return
        self._chain_data = data
        # Parse expirations
        calls = data.get("callExpDateMap",{}); puts = data.get("putExpDateMap",{})
        dates = sorted(set(
            [k.split(":")[0] for k in calls.keys()] +
            [k.split(":")[0] for k in puts.keys()]
        ))
        self._opt_exp.blockSignals(True)
        self._opt_exp.clear()
        self._opt_exp.addItems(dates)
        self._opt_exp.blockSignals(False)
        if dates:
            self._opt_exp.setCurrentIndex(0)
            self._on_exp_changed(dates[0])

    def _on_exp_changed(self, date_str):
        self._populate_strikes(date_str, self._opt_cp.currentText())

    def _on_cp_changed(self, cp):
        self._populate_strikes(self._opt_exp.currentText(), cp)

    def _populate_strikes(self, date_str, cp):
        if not self._chain_data: return
        exp_map = self._chain_data.get("callExpDateMap" if cp=="CALL" else "putExpDateMap",{})
        strikes = []
        for key, inner in exp_map.items():
            if key.split(":")[0] == date_str:
                for strike_str in inner.keys():
                    try: strikes.append(float(strike_str))
                    except: pass
        strikes.sort()
        self._opt_strike.blockSignals(True)
        self._opt_strike.clear()
        self._opt_strike.addItems([f"{s:.2f}" if s!=int(s) else f"{int(s)}" for s in strikes])
        self._opt_strike.blockSignals(False)
        # Find ATM
        under = self._chain_data.get("underlyingPrice",0)
        if under and strikes:
            atm = min(strikes, key=lambda s: abs(s-under))
            idx = strikes.index(atm)
            self._opt_strike.setCurrentIndex(idx)
        self._on_strike_changed(self._opt_strike.currentText())

    def _on_strike_changed(self, strike_str):
        if not strike_str: return
        date_str = self._opt_exp.currentText()
        cp       = self._opt_cp.currentText()
        sym      = self._opt_sym.text().strip().upper()
        # Build OCC symbol
        try:
            from datetime import datetime
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            date_part = dt.strftime("%y%m%d")
        except: date_part = "000000"
        c_p = "C" if cp=="CALL" else "P"
        try: strike = float(strike_str)
        except: return
        sym_padded = sym.ljust(6)
        strike_int = int(round(strike*1000))
        occ_sym = f"{sym_padded}{date_part}{c_p}{strike_int:08d}"
        self._opt_contract_lbl.setText(occ_sym)

        # Get bid/ask for this contract
        exp_map = self._chain_data.get("callExpDateMap" if cp=="CALL" else "putExpDateMap",{})
        for key, inner in exp_map.items():
            if key.split(":")[0] == date_str:
                for sk, contracts in inner.items():
                    try:
                        if abs(float(sk)-strike)<0.001 and contracts:
                            contract = contracts[0]
                            bid = float(contract.get("bid",0) or 0)
                            ask = float(contract.get("ask",0) or 0)
                            self._opt_contract_price.setText(
                                f"<span style='color:#3fb950'>Bid: ${bid:.2f}</span>   "
                                f"<span style='color:#f85149'>Ask: ${ask:.2f}</span>")
                            # Auto-set limit price
                            instr = self._opt_instr.currentText()
                            if "BUY" in instr:
                                self._opt_lim.setValue(ask)
                            else:
                                self._opt_lim.setValue(bid)
                            return
                    except: pass

    # ── UI HELPERS ───────────────────────────────────────────

    def _toggle_eq_prices(self, otype):
        show_lim  = otype in ("LIMIT","STOP_LIMIT")
        show_stop = otype in ("STOP","STOP_LIMIT")
        self._eq_lim_lbl.setVisible(show_lim)
        self._eq_lim.setVisible(show_lim)
        self._eq_stop_lbl.setVisible(show_stop)
        self._eq_stop.setVisible(show_stop)

    def _update_eq_btn(self, instr=None):
        instr = instr or self._eq_instr.currentText()
        is_buy = "BUY" in instr
        color = "#238636" if is_buy else "#da3633"
        hover = "#2ea043" if is_buy else "#f85149"
        self._eq_btn.setStyleSheet(f"QPushButton{{background:{color};color:#fff;border:none;border-radius:6px;font-size:14px;font-weight:bold;}} QPushButton:hover{{background:{hover};}}")

    def _update_opt_btn(self, instr=None):
        instr = instr or self._opt_instr.currentText()
        is_buy = "BUY" in instr
        color = "#238636" if is_buy else "#da3633"
        hover = "#2ea043" if is_buy else "#f85149"
        self._opt_btn.setStyleSheet(f"QPushButton{{background:{color};color:#fff;border:none;border-radius:6px;font-size:14px;font-weight:bold;}} QPushButton:hover{{background:{hover};}}")

    def _update_eq_est(self):
        qty   = self._eq_qty.value()
        price = self._eq_lim.value() or self._last_price
        if price>0 and qty>0:
            self._eq_est.setText(f"Est. value: {qty} × ${price:.2f} = ${qty*price:,.2f}")

    # ── SEND ORDERS ──────────────────────────────────────────

    def _send_equity(self):
        sym   = self._sym_input.text().strip().upper()
        if not sym: notify("No Symbol","warning",subtitle="Enter a symbol",duration=3000); return
        instr = self._eq_instr.currentText()
        otype = self._eq_otype.currentText()
        qty   = self._eq_qty.value()
        sess  = self._eq_sess.currentText()
        dur   = self._eq_dur.currentText()
        lp    = self._eq_lim.value()  if otype in ("LIMIT","STOP_LIMIT") else None
        sp    = self._eq_stop.value() if otype in ("STOP","STOP_LIMIT")  else None
        try:
            order = self.api.build_stock_order(sym,qty,instr,otype,lp,sp,session=sess,duration=dur)
            ok,msg = self.api.place_order(order)
            if ok:
                is_buy = "BUY" in instr
                trade_store.add_trade(sym,"BUY" if is_buy else "SELL",lp or self._last_price,qty,otype)
                notify(f"{'🟢 BUY' if is_buy else '🔴 SELL'}  {qty}× {sym}",
                       "fill",subtitle=f"${lp or self._last_price:.2f}  |  {otype}",duration=5000)
            else:
                notify(f"❌ Order Rejected — {sym}","reject",
                       subtitle=msg[:100] if msg else "Rejected by broker",duration=7000)
        except Exception as e:
            notify("Order Error","reject",subtitle=str(e)[:100],duration=7000)

    def _send_option(self):
        occ_sym = self._opt_contract_lbl.text().strip()
        if not occ_sym or occ_sym=="—":
            notify("No Contract","warning",subtitle="Load a chain and select a contract",duration=3000); return
        instr = self._opt_instr.currentText()
        qty   = self._opt_qty.value()
        lp    = self._opt_lim.value()
        sess  = self._opt_sess.currentText()
        dur   = self._opt_dur.currentText()
        otype = "LIMIT" if lp>0 else "MARKET"
        order = {
            "orderType": otype, "session": sess, "duration": dur,
            "orderStrategyType":"SINGLE",
            "orderLegCollection":[{
                "instruction":instr,"quantity":qty,
                "instrument":{"symbol":occ_sym,"assetType":"OPTION"}
            }]
        }
        if lp>0: order["price"] = str(round(lp,2))
        try:
            ok,msg = self.api.place_order(order)
            if ok:
                is_buy = "BUY" in instr
                notify(f"{'🟢' if is_buy else '🔴'}  {instr.replace('_',' ')}  {qty}× {occ_sym.strip()}",
                       "fill",subtitle=f"${lp:.2f}  |  {otype}",duration=5000)
            else:
                notify(f"❌ Order Rejected","reject",
                       subtitle=msg[:100] if msg else "Rejected by broker",duration=7000)
        except Exception as e:
            notify("Order Error","reject",subtitle=str(e)[:100],duration=7000)

    def closeEvent(self, event):
        self._price_timer.stop()
        super().closeEvent(event)
